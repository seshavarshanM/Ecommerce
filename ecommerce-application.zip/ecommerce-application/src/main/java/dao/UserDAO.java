package dao;

import java.sql.*;
import java.util.*;
import model.User;

public class UserDAO {

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/e_commerce_app", "root", "root@39");
    }

    // ── Helper: ResultSet → User ──────────────────────────────
    private User mapRow(ResultSet rs) throws Exception {
        User u = new User();
        u.setUserId(rs.getInt("u_id"));
        u.setUserName(rs.getString("u_name"));
        u.setUserEmail(rs.getString("u_email"));
        u.setUserPassword(rs.getString("u_pass"));
        u.setUserType(rs.getString("u_type"));
        return u;
    }

    // ── INSERT ────────────────────────────────────────────────
    public boolean insert(User u) {
        String sql = "INSERT INTO user (u_name, u_email, u_pass, u_type) VALUES (?,?,?,?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, u.getUserName());
            ps.setString(2, u.getUserEmail());
            ps.setString(3, u.getUserPassword());
            ps.setString(4, u.getUserType());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false; // duplicate email etc.
        }
    }

    // ── DELETE ✅ NEW ─────────────────────────────────────────
    public void delete(User u) {
        // Also clean up their cart entries first (FK safety)
        String deleteCart = "DELETE FROM cart WHERE u_id=?";
        String deleteUser = "DELETE FROM user WHERE u_id=?";
        try (Connection conn = getConnection()) {
            // Remove cart items
            try (PreparedStatement ps = conn.prepareStatement(deleteCart)) {
                ps.setInt(1, u.getUserId());
                ps.executeUpdate();
            }
            // Remove user
            try (PreparedStatement ps = conn.prepareStatement(deleteUser)) {
                ps.setInt(1, u.getUserId());
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── LOGIN ─────────────────────────────────────────────────
    public User getUserByEmailAndPassword(String email, String password) {
        String sql = "SELECT * FROM user WHERE u_email=? AND u_pass=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ── GET BY ID ─────────────────────────────────────────────
    public User getUserById(int id) {
        String sql = "SELECT * FROM user WHERE u_id=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ── GET ALL ───────────────────────────────────────────────
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM user ORDER BY u_id";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}