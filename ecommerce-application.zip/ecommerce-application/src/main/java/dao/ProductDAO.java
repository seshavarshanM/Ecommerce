package dao;

import java.sql.*;
import java.util.*;
import model.Product;

public class ProductDAO implements ProductDAOInterface {

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/e_commerce_app", "root", "root@39");
    }

    // ── Helper: ResultSet → Product ───────────────────────────
    private Product mapRow(ResultSet rs) throws Exception {
        Product p = new Product();
        p.setProductId(rs.getInt("p_id"));
        p.setProductName(rs.getString("p_name"));
        p.setProductCategory(rs.getString("category"));
        p.setProductDescription(rs.getString("description"));
        p.setProductQuantity(rs.getInt("quantity"));
        p.setProductPrice(rs.getDouble("price"));
        p.setImage(rs.getString("image"));
        return p;
    }

    // ── INSERT ✅ includes image ───────────────────────────────
    @Override
    public boolean insert(Product p) {
        String sql = "INSERT INTO product (p_name, category, description, quantity, price, image) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getProductName());
            ps.setString(2, p.getProductCategory());
            ps.setString(3, p.getProductDescription());
            ps.setInt(4, p.getProductQuantity());
            ps.setDouble(5, p.getProductPrice());
            ps.setString(6, p.getImage()); // ✅ image saved
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ── UPDATE ✅ includes image ───────────────────────────────
    @Override
    public void update(Product p) {
        String sql = "UPDATE product SET p_name=?, category=?, description=?, " +
                     "quantity=?, price=?, image=? WHERE p_id=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getProductName());
            ps.setString(2, p.getProductCategory());
            ps.setString(3, p.getProductDescription());
            ps.setInt(4, p.getProductQuantity());
            ps.setDouble(5, p.getProductPrice());
            ps.setString(6, p.getImage()); // ✅ image updated
            ps.setInt(7, p.getProductId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── DELETE ───────────────────────────────────────────────
    @Override
    public void delete(Product p) {
        String sql = "DELETE FROM product WHERE p_id=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, p.getProductId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ── GET BY ID ─────────────────────────────────────────────
    @Override
    public Product getByProductId(int id) {
        String sql = "SELECT * FROM product WHERE p_id=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // ── GET ALL ───────────────────────────────────────────────
    @Override
    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM product ORDER BY category, p_name";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}