package dao;

import java.sql.*;
import java.util.*;
import model.CartItem;

/**
 * CartDAO — all cart operations stored in DB (u_id, p_id, quantity).
 * This ensures the cart syncs across all browsers/devices for the same user.
 */
public class CartDAO {

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/e_commerce_app", "root", "root@39");
    }

    /**
     * Add item to cart. If already exists → increase quantity.
     * Caps quantity at available stock.
     */
    public boolean addToCart(int userId, int productId, int quantity) {
        try (Connection conn = getConnection()) {

            // Check current stock
            int stock = 0;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT quantity FROM product WHERE p_id=?")) {
                ps.setInt(1, productId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) stock = rs.getInt("quantity");
            }
            if (stock <= 0) return false;

            // Check if already in cart
            int existing = 0;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT quantity FROM cart WHERE u_id=? AND p_id=?")) {
                ps.setInt(1, userId);
                ps.setInt(2, productId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) existing = rs.getInt("quantity");
            }

            int newQty = Math.min(existing + quantity, stock);

            if (existing > 0) {
                // Update existing row
                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE cart SET quantity=? WHERE u_id=? AND p_id=?")) {
                    ps.setInt(1, newQty);
                    ps.setInt(2, userId);
                    ps.setInt(3, productId);
                    ps.executeUpdate();
                }
            } else {
                // Insert new row
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO cart (u_id, p_id, quantity) VALUES (?,?,?)")) {
                    ps.setInt(1, userId);
                    ps.setInt(2, productId);
                    ps.setInt(3, newQty);
                    ps.executeUpdate();
                }
            }
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Get all cart items for a user — joins with product table for name, price, image.
     */
    public List<CartItem> getCartItems(int userId) {
        List<CartItem> items = new ArrayList<>();
        String sql = "SELECT c.p_id, p.p_name, p.price, p.image, c.quantity, p.quantity AS stock " +
                     "FROM cart c JOIN product p ON c.p_id = p.p_id " +
                     "WHERE c.u_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                CartItem item = new CartItem();
                item.setProductId(rs.getInt("p_id"));
                item.setName(rs.getString("p_name"));
                item.setPrice(rs.getDouble("price"));
                item.setImage(rs.getString("image"));
                item.setQuantity(rs.getInt("quantity"));
                item.setStock(rs.getInt("stock"));
                items.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return items;
    }

    /**
     * Update quantity of a specific item. Pass 0 to remove.
     */
    public void updateQuantity(int userId, int productId, int quantity) {
        try (Connection conn = getConnection()) {
            if (quantity <= 0) {
                try (PreparedStatement ps = conn.prepareStatement(
                        "DELETE FROM cart WHERE u_id=? AND p_id=?")) {
                    ps.setInt(1, userId);
                    ps.setInt(2, productId);
                    ps.executeUpdate();
                }
            } else {
                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE cart SET quantity=? WHERE u_id=? AND p_id=?")) {
                    ps.setInt(1, quantity);
                    ps.setInt(2, userId);
                    ps.setInt(3, productId);
                    ps.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Remove a single item from cart.
     */
    public void removeItem(int userId, int productId) {
        updateQuantity(userId, productId, 0);
    }

    /**
     * Clear entire cart for a user (called after checkout).
     */
    public void clearCart(int userId) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "DELETE FROM cart WHERE u_id=?")) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Count total items in cart (for badge).
     */
    public int getCartCount(int userId) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT SUM(quantity) FROM cart WHERE u_id=?")) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
