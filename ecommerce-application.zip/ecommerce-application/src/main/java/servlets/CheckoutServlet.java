package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.CartItem;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("id");

        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

        if (userId == null || cart == null || cart.isEmpty()) {
            response.sendRedirect("cart.jsp");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/e_commerce_app", "root", "akash9851"
            );

            conn.setAutoCommit(false);

            // 1️⃣ calculate total
            double total = 0;
            for (CartItem c : cart) total += c.getPrice() * c.getQuantity();

            // 2️⃣ insert order
            PreparedStatement pst = conn.prepareStatement(
                "INSERT INTO orders(user_id, total_amount) VALUES(?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );

            pst.setInt(1, userId);
            pst.setDouble(2, total);
            pst.executeUpdate();

            ResultSet rs = pst.getGeneratedKeys();
            rs.next();
            int orderId = rs.getInt(1);

            // 3️⃣ insert order items + reduce stock
            PreparedStatement itemPst = conn.prepareStatement(
                "INSERT INTO order_items(order_id, product_id, quantity, price) VALUES(?,?,?,?)"
            );

            PreparedStatement stockPst = conn.prepareStatement(
                "UPDATE product SET quantity = quantity - ? WHERE p_id=?"
            );

            for (CartItem c : cart) {

                itemPst.setInt(1, orderId);
                itemPst.setInt(2, c.getProductId());
                itemPst.setInt(3, c.getQuantity());
                itemPst.setDouble(4, c.getPrice());
                itemPst.executeUpdate();

                stockPst.setInt(1, c.getQuantity());
                stockPst.setInt(2, c.getProductId());
                stockPst.executeUpdate();
            }

            conn.commit();

            // 4️⃣ clear cart
            session.removeAttribute("cart");

            response.sendRedirect("products?success=ordered");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("cart.jsp?error=checkout");
        }
    }
}
