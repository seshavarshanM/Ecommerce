package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import dao.UserDAO;
import model.User;

@WebServlet("/deleteUserServlet")
public class DeleteUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.trim().equals("a")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            // Safety: prevent admin from deleting their own account
            Integer currentAdminId = (Integer) session.getAttribute("id");
            if (currentAdminId != null && currentAdminId == id) {
                response.sendRedirect(request.getContextPath()
                        + "/showUsers?error=cannot_delete_self");
                return;
            }

            User u = new User();
            u.setUserId(id);

            UserDAO dao = new UserDAO();
            dao.delete(u);

            // ✅ FIX: redirect with success param so toast shows
            response.sendRedirect(request.getContextPath()
                    + "/showUsers?success=deleted");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath()
                    + "/showUsers?error=error");
        }
    }
}