package servlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.ProductDAO;
import model.Product;

@WebServlet({"", "/", "/products", "/home"})
public class ShowUserProducts extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        ProductDAO dao = new ProductDAO();
        List<Product> products = dao.getAllProducts();
        req.setAttribute("products", products);

        // FIXED: use absolute path starting with "/"
        // Without "/" Tomcat resolves relative to current URL path — causes the bug
        req.getRequestDispatcher("/home.jsp").forward(req, res);
    }
}