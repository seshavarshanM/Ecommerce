package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.CartDAO;

@WebServlet("/addToCart")
public class AddToCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        Integer userId = (Integer) req.getSession().getAttribute("id");

        // Must be logged in
        if (userId == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp?error=login_required");
            return;
        }

        int productId = 0;
        int quantity  = 1;

        try { productId = Integer.parseInt(req.getParameter("productId")); }
        catch (Exception ignored) {}

        try { quantity = Integer.parseInt(req.getParameter("quantity")); }
        catch (Exception ignored) {}

        if (quantity < 1) quantity = 1;

        CartDAO cartDAO = new CartDAO();
        boolean added   = cartDAO.addToCart(userId, productId, quantity);

        if (added) {
            res.sendRedirect(req.getContextPath() + "/products?success=added");
        } else {
            res.sendRedirect(req.getContextPath() + "/products?error=outofstock");
        }
    }
}