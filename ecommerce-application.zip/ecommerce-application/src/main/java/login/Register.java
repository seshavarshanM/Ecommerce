package login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.UserDAO;
import model.User;

@WebServlet("/register")
public class Register extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String uname = request.getParameter("uname");
        String email = request.getParameter("email");
        String pass  = request.getParameter("pass");
        String cpass = request.getParameter("cpass");

        // Guard: password mismatch → redirect back with error param
        if (pass == null || !pass.equals(cpass)) {
            response.sendRedirect(request.getContextPath()
                    + "/register.jsp?error=password_mismatch");
            return;
        }

        // Guard: short password
        if (pass.length() < 6) {
            response.sendRedirect(request.getContextPath()
                    + "/register.jsp?error=error");
            return;
        }

        User u = new User();
        u.setUserName(uname.trim());
        u.setUserEmail(email.trim());
        u.setUserPassword(pass);
        u.setUserType("c");

        UserDAO dao     = new UserDAO();
        boolean success = dao.insert(u);

        if (success) {
            // Redirect to login with success info message
            response.sendRedirect(request.getContextPath()
                    + "/login.jsp?info=registered");
        } else {
            // insert() returned false → likely duplicate email
            response.sendRedirect(request.getContextPath()
                    + "/register.jsp?error=email_exists");
        }
    }
}