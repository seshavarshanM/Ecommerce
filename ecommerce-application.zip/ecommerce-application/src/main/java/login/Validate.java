package login;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.UserDAO;
import model.User;

@WebServlet("/validate")
public class Validate extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email    = request.getParameter("email");
        String password = request.getParameter("pass");

        // Guard: empty fields
        if (email == null || email.trim().isEmpty()
         || password == null || password.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=invalid");
            return;
        }

        UserDAO dao  = new UserDAO();
        User    user = dao.getUserByEmailAndPassword(email.trim(), password);

        if (user != null) {
            HttpSession session = request.getSession(true);
            session.setAttribute("id",    user.getUserId());
            session.setAttribute("utype", user.getUserType());
            session.setAttribute("uname", user.getUserName());

            String utype = user.getUserType();
            if ("c".equals(utype.trim())) {
                response.sendRedirect(request.getContextPath() + "/products");
            } else if ("a".equals(utype.trim())) {
                RequestDispatcher rd = request.getRequestDispatcher("/AdminWelcome.jsp");
                rd.forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/products");
            }
        } else {
            // Wrong credentials
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=invalid");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }
}