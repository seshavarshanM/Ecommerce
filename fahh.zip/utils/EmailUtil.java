package utils;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailUtil {

	public static boolean sendOTPForLoginEmail(String to, String subject, String otp) {

		final String fromEmail = "akash.adhya.in@gmail.com";
		final String password = "olwzscyplsevjlts";

		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");

		try {
			Session session = Session.getInstance(props, new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(fromEmail, password);
				}
			});

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromEmail));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject(subject);

			String html = buildModernEmailTemplate(otp);

			message.setContent(html, "text/html; charset=utf-8");

			Transport.send(message);

			return true;

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	private static String buildModernEmailTemplate(String otp) {
		return "<!DOCTYPE html>" + "<html lang='en'>" + "<head>" + "  <meta charset='UTF-8'>"
				+ "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>"
				+ "  <title>Login Verification</title>" + "</head>"

				+ "<body style='margin:0;padding:0;background:#f4f6fb;font-family:Segoe UI,Roboto,Arial,sans-serif;'>"

				// Outer wrapper
				+ "<table width='100%' cellpadding='0' cellspacing='0' style='padding:40px 16px;background:#f4f6fb;'>"
				+ "<tr><td align='center'>"

				// Card container
				+ "<table width='100%' style='max-width:600px;background:#ffffff;border-radius:18px;"
				+ "box-shadow:0 10px 30px rgba(0,0,0,0.08);overflow:hidden;'>"

				// ===== HEADER =====
				+ "<tr>"
				+ "<td style='background:linear-gradient(135deg,#6366f1,#7c3aed);padding:42px 28px;text-align:center;color:#fff;'>"
				+ "<div style='font-size:42px;margin-bottom:10px;'>🔐</div>"
				+ "<h1 style='margin:0;font-size:26px;font-weight:600;'>Verify your login</h1>"
				+ "<p style='margin:8px 0 0;font-size:14px;opacity:0.9;'>Secure access to your account</p>" + "</td>"
				+ "</tr>"

				// ===== CONTENT =====
				+ "<tr><td style='padding:36px 28px;'>"

				+ "<p style='margin:0 0 18px;font-size:16px;color:#374151;text-align:center;'>"
				+ "We detected a login attempt. Enter the verification code below to continue." + "</p>"

				// OTP BOX
				+ "<div style='background:linear-gradient(135deg,#6366f1,#7c3aed);"
				+ "border-radius:14px;padding:26px;text-align:center;color:#fff;margin:28px 0;'>"
				+ "<p style='margin:0 0 10px;font-size:12px;letter-spacing:1px;text-transform:uppercase;opacity:0.85;'>"
				+ "Your One-Time Code</p>"
				+ "<div style='background:rgba(255,255,255,0.15);border-radius:10px;padding:14px;'>"
				+ "<span style='font-size:38px;font-weight:700;letter-spacing:8px;font-family:Courier New,monospace;'>"
				+ otp + "</span>" + "</div>"
				+ "<p style='margin:12px 0 0;font-size:13px;opacity:0.9;'>⏱ Expires in 5 minutes</p>" + "</div>"


				// SECURITY NOTE
				+ "<div style='background:#fff7ed;border-left:4px solid #f59e0b;"
				+ "border-radius:8px;padding:16px;margin-top:24px;'>"
				+ "<p style='margin:0;font-size:14px;color:#92400e;'>"
				+ "<strong>Security notice:</strong> Never share this code with anyone. "
				+ "Our team will never ask for your verification code." + "</p>" + "</div>"

				+ "<p style='margin:24px 0 0;font-size:13px;color:#6b7280;text-align:center;'>"
				+ "If this wasn’t you, please secure your account immediately." + "</p>"

				+ "</td></tr>"

				// ===== FOOTER =====
				+ "<tr>" + "<td style='background:#f9fafb;border-top:1px solid #e5e7eb;"
				+ "padding:26px;text-align:center;font-size:12px;color:#9ca3af;'>"

				+ "<p style='margin:0 0 6px;'>This is an automated email — please do not reply.</p>"
				+ "<p style='margin:0;'>© 2026 Your Company. All rights reserved.</p>"

				+ "<div style='margin-top:12px;'>"
				+ "<a href='#' style='margin:0 8px;color:#6b7280;text-decoration:none;'>Privacy</a>" + "•"
				+ "<a href='#' style='margin:0 8px;color:#6b7280;text-decoration:none;'>Terms</a>" + "•"
				+ "<a href='#' style='margin:0 8px;color:#6b7280;text-decoration:none;'>Support</a>" + "</div>"

				+ "</td>" + "</tr>"

				+ "</table>" + "</td></tr></table>" + "</body></html>";
	}
}
