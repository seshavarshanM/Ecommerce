package pages;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.ProductDAO;
import model.Product;

@WebServlet("/add")
public class AddProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.equals("a")) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            
            String productName = request.getParameter("productName");
            String productDescription = request.getParameter("productDescription");
            String productCategory = request.getParameter("productCategory");

            int productQuantity = Integer.parseInt(request.getParameter("productQuantity"));
            double price = Double.parseDouble(request.getParameter("productPrice"));

            
            Product p = new Product();
            p.setProductName(productName);
            p.setProductCategory(productCategory);
            p.setProductDescription(productDescription);
            p.setProductQuantity(productQuantity);
            p.setProductPrice(price);

            
            ProductDAO dao = new ProductDAO();
            boolean status = dao.insert(p);

            if (status) {
               
                response.sendRedirect("AdminDashboard");
            } else {
                response.getWriter().println("<h3>Failed to add product</h3>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h3>Error occurred while adding product</h3>");
        }
    }
}
