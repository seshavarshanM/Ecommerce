package pages;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.ProductDAO;
import model.Product;

@WebServlet("/edit")
public class EditProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.equals("a")) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            // 📥 Get form values
            int id = Integer.parseInt(request.getParameter("productId"));
            String name = request.getParameter("productName");
            String category = request.getParameter("productCategory");
            String desc = request.getParameter("productDescription");
            int qty = Integer.parseInt(request.getParameter("productQuantity"));
            double price = Double.parseDouble(request.getParameter("productPrice"));

            
            Product p = new Product();
            p.setProductId(id);
            p.setProductName(name);
            p.setProductCategory(category);
            p.setProductDescription(desc);
            p.setProductQuantity(qty);
            p.setProductPrice(price);

            
            ProductDAO dao = new ProductDAO();
            dao.update(p);

            
            response.sendRedirect("AdminDashboard");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h3>Error updating product</h3>");
        }
    }
}
