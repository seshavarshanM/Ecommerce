package servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.CartDAO;
import model.CartItem;

@WebServlet("/updateCart")
public class UpdateCartServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("id");

        String action = request.getParameter("action");
        String productParam = request.getParameter("productId");

        int productId = 0;
        if (productParam != null) {
            productId = Integer.parseInt(productParam);
        }

        /* user logged in */
        if (userId != null) {

            CartDAO cartDAO = new CartDAO();

            switch (action) {

                case "update":
                    int qty = Integer.parseInt(request.getParameter("quantity"));

                    if (qty <= 0) {
                        cartDAO.removeItem(userId, productId);
                    } else {
                        cartDAO.updateQuantity(userId, productId, qty);
                    }
                    break;

                case "remove":
                    cartDAO.removeItem(userId, productId);
                    break;

                case "clear":
                    cartDAO.clearCart(userId);
                    break;
            }
        }

        /* guest user */
        else {

            List<CartItem> cart =
                    (List<CartItem>) session.getAttribute("cart");

            if (cart == null) cart = new ArrayList<>();

            switch (action) {

                case "update":
                    int qty = Integer.parseInt(request.getParameter("quantity"));

                    for (CartItem item : cart) {
                        if (item.getProductId() == productId) {
                            if (qty <= 0) {
                                cart.remove(item);
                            } else {
                                item.setQuantity(qty);
                            }
                            break;
                        }
                    }
                    break;

                case "remove":
                    Iterator<CartItem> it = cart.iterator();
                    while (it.hasNext()) {
                        if (it.next().getProductId() == productId) {
                            it.remove();
                            break;
                        }
                    }
                    break;

                case "clear":
                    cart.clear();
                    break;
            }

            session.setAttribute("cart", cart);
        }

        
        response.sendRedirect("cart.jsp");
    }
}
