package servlets;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/verifyOtp")
public class VerifyOtpServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		String enteredOtp = request.getParameter("otp");
		String sessionOtp = (String) session.getAttribute("otp");
		Long otpTime = (Long) session.getAttribute("otp_time");

		long currentTime = System.currentTimeMillis();

		long OTP_VALIDITY = 5 * 60 * 1000;

		if (sessionOtp != null && otpTime != null) {

			
			if (currentTime - otpTime > OTP_VALIDITY) {

				session.removeAttribute("otp");
				session.removeAttribute("otp_time");

				response.sendRedirect("login.jsp?error=expired");
				return;
			}


			if (sessionOtp.equals(enteredOtp)) {

				session.setAttribute("id", session.getAttribute("temp_uid"));
				session.setAttribute("utype", session.getAttribute("temp_utype"));
				session.setAttribute("uname", session.getAttribute("temp_uname"));


				session.removeAttribute("otp");
				session.removeAttribute("otp_time");
				session.removeAttribute("temp_uid");
				session.removeAttribute("temp_utype");
				session.removeAttribute("temp_uname");

				String utype = (String) session.getAttribute("utype");

				if ("c".equals(utype.trim())) {
					response.sendRedirect("products");
				} else {
					response.sendRedirect("AdminWelcome.jsp");
				}

			} else {
				response.sendRedirect("otp.jsp?error=wrong");
			}

		} else {
			response.sendRedirect("login.jsp");
		}

	}
}
