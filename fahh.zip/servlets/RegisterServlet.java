package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAO;
import model.User;



@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String uname = request.getParameter("uname");
        String email = request.getParameter("email");
        String pass = request.getParameter("pass");
        String cpass = request.getParameter("cpass");

        if (!pass.equals(cpass)) {
            response.sendRedirect("register.jsp");
            return;
        }

        User u = new User();
        u.setUserName(uname);
        u.setUserEmail(email);
        u.setUserPassword(pass);
        u.setUserType("c");

        UserDAO dao = new UserDAO();
        dao.insert(u);

        response.sendRedirect("login.jsp");
    }
}
