package dao;

import java.util.List;

import model.User;

public interface UserDAOInterface {
	
	public void insert(User u);
	public void update(User u);
	public void delete(User u);
	
	public User getByUserId(int id);
	public List<User> getAllUsers();
	
}
