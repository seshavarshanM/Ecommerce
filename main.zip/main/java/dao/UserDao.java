package dao;

import java.sql.*;
import model.users;

public class UserDao {

    public void saveUser(users user) {

        String sql =
          "INSERT INTO users(uname, email, pass) VALUES (?, ?, ?)";

        try (Connection con = DriverManager.getConnection(
                 "jdbc:mysql://localhost:3306/e_commerce_app",
                 "root",
                 "root@39");
             PreparedStatement ps = con.prepareStatement(
                 sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, user.getUserName());
            ps.setString(2, user.getUserEmail());
            ps.setString(3, user.getUserPassword());

            ps.executeUpdate();

            // get auto-generated userid
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int generatedId = rs.getInt(1);
                user.setUserId(generatedId); // optional
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
