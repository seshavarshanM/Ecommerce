package transfer;

import java.sql.*;

import java.util.*;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class UserCacheListener
 *
 */
@WebListener
public class UserCacheListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public UserCacheListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    	
    	Map<String,String> userMap = new HashMap();
    	String jdbcurl = "jdbc:mysql://localhost:3306/e_commerce_app";
    	String user = "root";
    	String pass = "root@39";
    	
    	try {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		Connection con = DriverManager.getConnection(jdbcurl,user,pass);
    		PreparedStatement ps = con.prepareStatement(
    				"select email,password from users"
    				);
    		ResultSet rs = ps.executeQuery();
    		
    		while(rs.next()) {
    			userMap.put(rs.getString("email"),rs.getString("password"));
    		}
    		con.close();
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
    	sce.getServletContext().setAttribute("userMap", userMap);
        System.out.println("User cache loaded: " + userMap.size());
    }
	
}
