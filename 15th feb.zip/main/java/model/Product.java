package model;

public class Product {
	int productId;
	String productName;
	double productPrice;
	int productQuantity;
	String productCategory;
	String productDescrpition;


	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductDescrpition() {
		return productDescrpition;
	}

	public void setProductDescription(String productDescrpition) {
		this.productDescrpition = productDescrpition;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public int getProductId() {
		return productId;
	}

	public String getProductName() {
		return productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public String getProductCategry() {
		return productCategory;
	}

	public String getProductDescription() {
		return productDescrpition;
	}
	
	// for images
	public String getImage() {
		return null;
	}
}