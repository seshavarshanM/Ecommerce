package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.UserDAO;
import model.User;

@WebServlet("/deleteUserServlet")
public class DeleteUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.equals("a")) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            User u = new User();
            u.setUserId(id);

            UserDAO dao = new UserDAO();
            dao.delete(u);


            response.sendRedirect("showUsers");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error deleting user");
        }
    }
}
