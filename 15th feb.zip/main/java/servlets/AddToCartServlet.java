package servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CartDAO;
import dao.ProductDAO;
import model.CartItem;
import model.Product;

@WebServlet("/addToCart")
public class AddToCartServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

		HttpSession session = request.getSession();

		Integer userId = (Integer) session.getAttribute("id");

		int productId = Integer.parseInt(request.getParameter("productId"));
		int qty = Integer.parseInt(request.getParameter("quantity"));

		ProductDAO productDAO = new ProductDAO();
		Product p = productDAO.getByProductId(productId);

		// Out of stock 
		if (p == null || qty > p.getProductQuantity()) {
			response.sendRedirect("products?error=outofstock");
			return;
		}

		// save to db
		if (userId != null) {

			CartDAO cartDAO = new CartDAO();
			cartDAO.addToCart(userId, productId, qty);

		}
		
		// save to session
		else {

			List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

			if (cart == null)
				cart = new ArrayList<>();

			boolean found = false;

			for (CartItem item : cart) {
				if (item.getProductId() == productId) {
					item.setQuantity(item.getQuantity() + qty);
					found = true;
					break;
				}
			}

			if (!found) {
				CartItem item = new CartItem();
				item.setProductId(productId);
				item.setName(p.getProductName());
				item.setPrice(p.getProductPrice());
				item.setImage(p.getImage());
				item.setStock(p.getProductQuantity());
				item.setQuantity(qty);
				cart.add(item);
			}

			session.setAttribute("cart", cart);
		}

		response.sendRedirect("products?success=added");
	}
}
