package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.UserDAO;
import model.User;

@WebServlet("/showUsers")
public class ShowUsersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        HttpSession session = req.getSession();

        
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.equals("a")) {
            res.sendRedirect("login.jsp");
            return;
        }

        try {
            UserDAO dao = new UserDAO();
            List<User> users = dao.getAllUsers();

            req.setAttribute("users", users);

            req.getRequestDispatcher("showUsers.jsp").forward(req, res);

        } catch (Exception e) {
            e.printStackTrace();
            res.getWriter().println("Error loading users");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
