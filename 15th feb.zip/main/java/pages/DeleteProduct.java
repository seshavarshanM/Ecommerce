package pages;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.ProductDAO;
import model.Product;

@WebServlet("/delete")
public class DeleteProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.equals("a")) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            Product p = new Product();
            p.setProductId(id);

            ProductDAO dao = new ProductDAO();
            dao.delete(p);


            response.sendRedirect("AdminDashboard");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h3>Error deleting product</h3>");
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	

        HttpSession session = request.getSession();

        
        String utype = (String) session.getAttribute("utype");
        if (utype == null || !utype.equals("a")) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            Product p = new Product();
            p.setProductId(id);

            ProductDAO dao = new ProductDAO();
            dao.delete(p);


            response.sendRedirect("AdminDashboard");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h3>Error deleting product</h3>");
        }
        
    }
}
