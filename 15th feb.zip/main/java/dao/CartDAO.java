package dao;

import model.CartItem;
import java.sql.*;
import java.util.*;

public class CartDAO {

    private Connection conn;


    private void getConnection() {
        String url = "jdbc:mysql://localhost:3306/e_commerce_app";
        String username = "root";
        String password = "akash9851";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public List<CartItem> getCartItems(int userId) {
        List<CartItem> list = new ArrayList<>();

        String sql = "SELECT c.cart_id, c.user_id, c.product_id, c.quantity, " +
                     "p.p_name, p.price,  p.quantity " +
                     "FROM cart c JOIN product p ON c.product_id = p.p_id " +
                     "WHERE c.user_id=? ORDER BY c.added_at DESC";

        getConnection();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                CartItem item = new CartItem();

                item.setCartId(rs.getInt("cart_id"));
                item.setUserId(rs.getInt("user_id"));
                item.setProductId(rs.getInt("product_id"));
                item.setQuantity(rs.getInt("quantity"));

                item.setName(rs.getString("name"));
                item.setPrice(rs.getDouble("price"));
//                item.setImage(rs.getString("image"));
                item.setImage(null);
                item.setStock(rs.getInt("stock"));

                list.add(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }


    public void addToCart(int userId, int productId, int qty) {

        String sql = "INSERT INTO cart(user_id, product_id, quantity) " +
                     "VALUES(?,?,?) " +
                     "ON DUPLICATE KEY UPDATE quantity = quantity + ?";

        getConnection();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, productId);
            ps.setInt(3, qty);
            ps.setInt(4, qty);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    public void updateQuantity(int userId, int productId, int qty) {

        String sql = "UPDATE cart SET quantity=? WHERE user_id=? AND product_id=?";

        getConnection();
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, qty);
            ps.setInt(2, userId);
            ps.setInt(3, productId);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void removeItem(int userId, int productId) {

        String sql = "DELETE FROM cart WHERE user_id=? AND product_id=?";

        getConnection();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, productId);

            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void clearCart(int userId) {

        String sql = "DELETE FROM cart WHERE user_id=?";

        getConnection();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public CartItem getCartItem(int userId, int productId) {

        String sql = "SELECT * FROM cart WHERE user_id=? AND product_id=?";
        getConnection();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, productId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                CartItem item = new CartItem();
                item.setCartId(rs.getInt("cart_id"));
                item.setUserId(rs.getInt("user_id"));
                item.setProductId(rs.getInt("product_id"));
                item.setQuantity(rs.getInt("quantity"));
                return item;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}
